import React from "react";
import {
  Badge,
  Button,
  Container,
  Nav,
  Navbar,
  NavDropdown,
} from "react-bootstrap";
import logo from "../images/logo.svg";
import user from "../images/user.png";
import {
  FaFacebookF,
  FaInstagram,
  FaLinkedinIn,
  FaTwitter,
} from "react-icons/fa";
import {
  HeartOutlined,
  RollbackOutlined,
  SearchOutlined,
  ShoppingCartOutlined,
  UserOutlined,
} from "@ant-design/icons";

function NavBar() {
  return (
    <>
      <section className="navbar-section sticky-top">
        <Navbar expand="lg" className="bg-body-tertiary main-nav-div">
          <Navbar.Brand href="#home">
            <img src={logo} alt="" />
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="me-auto nav-btns-midel">
              <Nav.Link href="#home">
                <h1 className="nav-home">Home</h1>
              </Nav.Link>
              <NavDropdown
                title="Pizza"
                id="basic-nav-dropdown"
                className="multi-column-dropdown nav-pizz-text"
              >
                <div className="dropdown-columns">
                  <NavDropdown.Item
                    className="pizza-dropdown-text"
                    href="#action/1"
                  >
                    Veg Pizza
                  </NavDropdown.Item>
                  <NavDropdown.Item
                    className="pizza-dropdown-text"
                    href="#action/2"
                  >
                    Garlic Bread
                  </NavDropdown.Item>
                  <NavDropdown.Item
                    className="pizza-dropdown-text"
                    href="#action/3"
                  >
                    {" "}
                    Non-Veg Pizza
                  </NavDropdown.Item>
                  <NavDropdown.Item
                    className="pizza-dropdown-pera"
                    href="#action/4"
                  >
                    {" "}
                    Cheese Tomato
                  </NavDropdown.Item>
                  <NavDropdown.Item
                    href="#action/5"
                    className="pizza-dropdown-pera"
                  >
                    Crunchy Taco Bell
                  </NavDropdown.Item>
                  <NavDropdown.Item
                    href="#action/6"
                    className="pizza-dropdown-pera"
                  >
                    Cheese Fried Chicken
                  </NavDropdown.Item>
                  <NavDropdown.Item
                    href="#action/7"
                    className="pizza-dropdown-pera"
                  >
                    Margherita
                  </NavDropdown.Item>{" "}
                  <NavDropdown.Item
                    href="#action/8"
                    className="pizza-dropdown-pera"
                  >
                    Bread Rolls
                  </NavDropdown.Item>{" "}
                  <NavDropdown.Item
                    href="#action/9"
                    className="pizza-dropdown-pera"
                  >
                    Grilled Chicken Pizza
                  </NavDropdown.Item>{" "}
                  <NavDropdown.Item
                    href="#action/10"
                    className="pizza-dropdown-pera"
                  >
                    Masala Paneer
                  </NavDropdown.Item>{" "}
                  <NavDropdown.Item
                    href="#action/11"
                    className="pizza-dropdown-pera"
                  >
                    Hamburger Veggie
                  </NavDropdown.Item>{" "}
                  <NavDropdown.Item
                    href="#action/12"
                    className="pizza-dropdown-pera"
                  >
                    Paneer Chicken Pizza
                  </NavDropdown.Item>{" "}
                  <NavDropdown.Item
                    href="#action/13"
                    className="pizza-dropdown-pera"
                  >
                    Spinach Pizza
                  </NavDropdown.Item>{" "}
                  <NavDropdown.Item
                    href="#action/14"
                    className="pizza-dropdown-pera"
                  >
                    Ladi Paav
                  </NavDropdown.Item>{" "}
                  <NavDropdown.Item
                    href="#action/15"
                    className="pizza-dropdown-pera"
                  >
                    Spinach Pizza
                  </NavDropdown.Item>
                  <NavDropdown.Item
                    href="#action/16"
                    className="pizza-dropdown-pera"
                  >
                    Onion Blossom
                  </NavDropdown.Item>{" "}
                  <NavDropdown.Item
                    href="#action/17"
                    className="pizza-dropdown-pera"
                  >
                    Veggie Burrito
                  </NavDropdown.Item>{" "}
                  <NavDropdown.Item
                    href="#action/18"
                    className="pizza-dropdown-pera"
                  >
                    Crunchy Taco Bell
                  </NavDropdown.Item>
                </div>
              </NavDropdown>
              <Nav.Link href="#collections">
                <h1 className="nav-home">collections</h1>
              </Nav.Link>{" "}
              <NavDropdown
                title="snacks"
                id="basic-nav-dropdown"
                className="nav-snacks-text"
              >
                <div className="dropdown-column-snacks">
                  <NavDropdown.Item className="snacks-text" href="#action/3.1">
                    French Fries
                  </NavDropdown.Item>
                  <NavDropdown.Item className="snacks-text" href="#action/3.2">
                    Garlic Bread
                  </NavDropdown.Item>
                  <NavDropdown.Item className="snacks-text" href="#action/3.3">
                    Bread Rolls
                  </NavDropdown.Item>
                  <NavDropdown.Item className="snacks-text" href="#action/3.4">
                    Veg Pizza
                  </NavDropdown.Item>
                </div>
              </NavDropdown>{" "}
              <Nav.Link href="#Blogs">
                <h1 className="nav-home">Blogs</h1>
              </Nav.Link>{" "}
              <Nav.Link href="#Contact">
                <h1 className="nav-home">Contact</h1>
              </Nav.Link>{" "}
            </Nav>{" "}
          </Navbar.Collapse>{" "}
          <div className="nav-icons">
            <Button className="user-btn">
              <SearchOutlined className="user" />
            </Button>{" "}
            <Button className="user-btn">
              <UserOutlined className="user" />
            </Button>{" "}
            <Button className="user-btn">
              <HeartOutlined className="user" />
              <div className="noti-div">0</div>
            </Button>{" "}
            <Button className="user-btn">
              <ShoppingCartOutlined className="user" />
              <div className="noti-div">0</div>
            </Button>{" "}
          </div>
        </Navbar>
      </section>{" "}
    </>
  );
}

export default NavBar;
