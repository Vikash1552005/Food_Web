import { useState } from "react";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import "./App.css";
import "../src/Components/CSS/Responsive.css";
import Food_Web_Main from "./Components/App_Main/FoodWebMain";
import NavBar from "./Components/App_Main/NavBar";
import Footer from "./Components/App_Footer/Footer";
import FooterSec from "./Components/App_Footer/FooterSec";
import FooterMenu from "./Components/App_Footer/FooterMenu";

function App() {
  const [count, setCount] = useState(0);

  return (
    <>
      <NavBar />
      <Food_Web_Main />
      <Footer/>
      <FooterSec/>
      <FooterMenu/>
    </>
  );
}

export default App;
 
